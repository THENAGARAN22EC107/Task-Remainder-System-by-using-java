import java.util.*;

public class TaskReminder {
    static class Task {
        String taskName;
        String reminderTime;

        Task(String taskName, String reminderTime) {
            this.taskName = taskName;
            this.reminderTime = reminderTime;
        }
    }

    private static List<Task> taskList = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nTask Reminder App");
            System.out.println("1. Add Task");
            System.out.println("2. View Tasks");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    addTask(scanner);
                    break;
                case 2:
                    viewTasks();
                    break;
                case 3:
                    System.out.println("Exiting the application.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Method to add a task
    private static void addTask(Scanner scanner) {
        System.out.print("Enter task name: ");
        String taskName = scanner.nextLine();
        System.out.print("Enter reminder time (e.g., 10:00 AM): ");
        String reminderTime = scanner.nextLine();

        Task newTask = new Task(taskName, reminderTime);
        taskList.add(newTask);
        System.out.println("Task added successfully!");
    }

    // Method to view all tasks
    private static void viewTasks() {
        if (taskList.isEmpty()) {
            System.out.println("No tasks available.");
            return;
        }

        System.out.println("\nAll Tasks:");
        for (int i = 0; i < taskList.size(); i++) {
            Task task = taskList.get(i);
            System.out.println((i + 1) + ". Task: " + task.taskName + " | Reminder Time: " + task.reminderTime);
        }
    }
}
